# StS-Stuff-Mod  
Adds 40 Cards, 30 Exhibits from Slay the Spire to the game. Many contents from StS are already imported and redesigned in LBoL, so i focus on things that aren't in this game yet.  
You need BepInEx and LBoL-Entity-Sideloader to use this mod.

Installation(Github): Download StSStuffMod.dll and place it to Steam\steamapps\common\LBoL\BepInEx\plugins

Credit:  
Lost Branch of Legend by Alioth Studio  
Slay the Spire by Mega Crit  
BepInEx by BepInEx  
LBoL-Entity-Sideloader by Neoshrimp#7746
