# StS-Stuff-Mod  
Adds 46 Cards, 36 Exhibits from Slay the Spire to the game. Many contents from StS are already imported and redesigned in LBoL, so i focus on things that aren't in this game yet.  
You need BepInEx and LBoL-Entity-Sideloader to use this mod.

Credit:  
Lost Branch of Legend by Alioth Studio  
Slay the Spire by Mega Crit  
BepInEx by BepInEx  
LBoL-Entity-Sideloader by Neoshrimp#7746
