1.0.8: Added Sentinel. Madness should no longer target temporary 0 cost cards and mana freezed 0 cost cards.  
Fixed an issue that mana is not paying correctly if you play a card while another card is played by Double Tap or similar effects.  
1.0.7: Added 8 cards, 8 exhibits.  
Dramatic Entrance damage 22(24) -> 20(25). Caltrops cost 1WR -> WR. Busted Crown -2 -> -1 option. Ectoplasm makes Upgrading from a Gap free.  
Accuracy cost WW -> 1WW. Echo Form cost URG -> 2URG. Enlightenment now affects 0 cost cards.  
1.0.6: Added 12 cards, 5 exhibits.  
Dramatic Entrance is now Accurate, no longer Unplayable when upgraded. Necronomicon lose life removed, can now use exile cards twice.  
Fixed Ectoplasm not appearing at all. Pandora's Box should no longer appear if you don't have basic cards.  
1.0.5: Fixed an issue that unupgraded Dramatic Entrance is causing a softlock.  
1.0.4: Added Frozen Eye. Fixed Yukari not giving Border Sensor if you have Coffee Dripper and Fusion Hammer.  
1.0.3: Added 10 cards, 6 exhibits. Bug fix and balance changes.  
1.0.1: Added 4 exhibits: Coffee Dripper, Ectoplasm, Fusion Hammer, Sacred Bark  
1.0.0: Added 10 cards, 6 exhibits.