1.0.4: Added Frozen Eye. Fixed Yukari not giving Border Sensor if you have Coffee Dripper and Fusion Hammer.  
1.0.3: Added 10 cards, 6 exhibits. Bug fix and balance changes.  
1.0.1: Added 4 exhibits: Coffee Dripper, Ectoplasm, Fusion Hammer, Sacred Bark  
1.0.0: Added 10 cards, 6 exhibits.